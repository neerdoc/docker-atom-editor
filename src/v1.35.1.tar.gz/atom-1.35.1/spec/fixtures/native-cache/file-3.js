module.exports = function () { return 3; }
