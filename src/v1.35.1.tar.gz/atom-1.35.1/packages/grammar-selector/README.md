# Grammar Selector package

Pick the grammar used for syntax highlighting using <kbd>ctrl-shift-L</kbd> or by clicking the current grammar name in the status bar.

![](https://f.cloud.github.com/assets/671378/2241618/b7661f08-9cd9-11e3-8276-fe1c02955901.png)
