# language-rust-bundled

This package provides Rust syntax highlighting in Atom based on syntax trees provided by [tree-sitter-rust](https://github.com/tree-sitter/tree-sitter-rust).
