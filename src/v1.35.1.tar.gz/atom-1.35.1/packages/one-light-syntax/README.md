## One Light Syntax theme

![one-syntax-light](https://cloud.githubusercontent.com/assets/378023/7783214/c146b4e6-0174-11e5-8377-a57cf0274d5d.png)

> The font used in the screenshot is [Fira Mono](https://github.com/mozilla/Fira).

There is also a matching [UI theme](../one-light-ui).

### Install

This theme is installed by default with Atom and can be activated by going to the __Settings > Themes__ section and selecting it from the __Syntax Themes__ drop-down menu.
