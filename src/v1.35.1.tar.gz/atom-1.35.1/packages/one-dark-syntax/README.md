## One Dark Syntax theme

![one-dark-syntax](https://user-images.githubusercontent.com/238929/40553597-5f741518-6000-11e8-9068-70dfc5008b54.png)

> The font used in the screenshot is [Fira Mono](https://github.com/mozilla/Fira).

There is also a matching [UI theme](https://atom.io/themes/one-dark-ui).

### Install

This theme is installed by default with Atom and can be activated by going to the __Settings > Themes__ section and selecting it from the __Syntax Themes__ drop-down menu.
